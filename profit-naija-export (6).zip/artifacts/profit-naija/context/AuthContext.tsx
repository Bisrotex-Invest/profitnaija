import React, {
  createContext,
  useContext,
  useState,
  useCallback,
  ReactNode,
} from 'react';
import {
  User,
  ActionCodeSettings,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  applyActionCode,
  confirmPasswordReset,
  signOut as firebaseSignOut,
  updateProfile,
} from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { getAuthInstance, db } from '@/lib/firebase';

// ── Action code settings ──────────────────────────────────────────────────────
// handleCodeInApp: true tells Firebase to format links so Android intent filters
// can open the app directly instead of routing through the browser.
const ACTION_CODE_SETTINGS: ActionCodeSettings = {
  url: 'https://profitnaija.firebaseapp.com',
  handleCodeInApp: true,
  android: {
    packageName: 'com.profitnaija.app',
    installApp: false,
  },
  iOS: {
    bundleId: 'com.profitnaija.app',
  },
};

// ── Types ─────────────────────────────────────────────────────────────────────

interface AuthContextValue {
  user: User | null;
  signIn: (email: string, password: string) => Promise<User>;
  signUp: (name: string, phone: string, email: string, password: string) => Promise<User>;
  sendVerificationEmail: () => Promise<void>;
  forgotPassword: (email: string) => Promise<void>;
  /** Apply a verifyEmail oobCode from a Firebase email action link. */
  verifyEmailWithCode: (oobCode: string) => Promise<void>;
  /** Apply a resetPassword oobCode + new password from a Firebase email action link. */
  resetPasswordWithCode: (oobCode: string, newPassword: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

// ── Provider ──────────────────────────────────────────────────────────────────

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const signIn = useCallback(async (email: string, password: string): Promise<User> => {
    const a = await getAuthInstance();
    const cred = await signInWithEmailAndPassword(a, email.trim(), password);
    setUser(cred.user);
    return cred.user;
  }, []);

  const signUp = useCallback(async (name: string, phone: string, email: string, password: string): Promise<User> => {
    const a = await getAuthInstance();
    const cred = await createUserWithEmailAndPassword(a, email.trim(), password);
    // Fire-and-forget — do NOT await these; they can hang on slow networks
    // and block the user from reaching the dashboard.
    if (name.trim()) {
      updateProfile(cred.user, { displayName: name.trim() }).catch(() => {});
    }
    setDoc(doc(db, 'users', cred.user.uid), {
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      createdAt: Date.now(),
    }).catch(() => {});
    setUser(cred.user);
    return cred.user;
  }, []);

  const sendVerificationEmail = useCallback(async () => {
    const u = (await getAuthInstance()).currentUser;
    if (!u) throw new Error('No authenticated user. Please sign in first.');
    await sendEmailVerification(u, ACTION_CODE_SETTINGS);
  }, []);

  const forgotPassword = useCallback(async (email: string) => {
    const a = await getAuthInstance();
    await sendPasswordResetEmail(a, email.trim(), ACTION_CODE_SETTINGS);
  }, []);

  const verifyEmailWithCode = useCallback(async (oobCode: string) => {
    const a = await getAuthInstance();
    await applyActionCode(a, oobCode);
    // Refresh the local user so emailVerified reflects the change
    await a.currentUser?.reload();
    setUser(a.currentUser);
  }, []);

  const resetPasswordWithCode = useCallback(async (oobCode: string, newPassword: string) => {
    const a = await getAuthInstance();
    await confirmPasswordReset(a, oobCode, newPassword);
  }, []);

  const signOut = useCallback(async () => {
    try {
      const a = await getAuthInstance();
      await firebaseSignOut(a);
    } catch {
      // Swallow — always clear local state
    } finally {
      setUser(null);
    }
  }, []);

  return (
    <AuthContext.Provider value={{ user, signIn, signUp, sendVerificationEmail, forgotPassword, verifyEmailWithCode, resetPasswordWithCode, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
